#pragma once
typedef double number;