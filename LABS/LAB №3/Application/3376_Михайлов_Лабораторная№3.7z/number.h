#pragma once
#include "Complex.h"
typedef Complex number;